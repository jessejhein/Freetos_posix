/*
 *	linlike8/test_apps/process0.c
 *
 *	originally in linux as idle task with cpu sleep to save power.
 *	However, we don't want to waste the cpu power and stack size for this process in this small system(8-bit system is resource limitation, especially memory in rom and ram), 
 *	This should have something to do for system, such as monitoring in embbeded system.
 *	This process is always running, can't have sleep(means must always active), but lowest priority, so should do the task for always working but not significant
 *
 *	14-04-2004	yan	just for test, real application should be have some job to do
 *	25-05-2004	yan	change process0 as a system process
 *				adding the scan key procedures here combined with gpio module
 *	10-06-2004	yan	process0 still as a system process, it cannot be sleep, must always running.
 *				this process can do some time delay by alarm()
 *				remove the scan key from this process, since moving to gpio module
 *
 */

#include "app.h"
#include "i2c.h"

#ifdef CYPRESS_PSOC
	#include "sched.h"								// linlike8 system
	#include "timer.h"
	#include <m8c.h>								// application 
	#include "PSoCAPI.h"
#if (SERIAL_MOD>0)
	#include "serial.h"								// read()
#endif
#endif

#ifdef I386_LINUX
	#include <sched.h>
	#include <stdio.h>
	#include <unistd.h>
#endif

#ifdef CYPRESS_PSOC
unsigned char a_glo = 0;
#endif
#ifdef I386_LINUX
extern unsigned char* shmaddr;
#define	a_glo *shmaddr
#endif
void process0(void)
{
	
	unsigned char i = 0;
	unsigned char buf[8];
	unsigned char buf_b[8];
	unsigned char rd_wr_status=0;
	//I2CHW_1_EnableSlave();				// Enable Slave Op
	//I2CHW_1_EnableInt();				// Enable I2C Interrupt
	//I2CHW_1_InitRamRead(buf,5);	// Initialize Read Buffer
	//M8C_EnableGInt;						//
	unsigned int x=0;
		//for(i=0;i<20000;i++){};
		
		while(1)
		{
			
			switch (rd_wr_status)
			{
			case 0:
			//for(i=0;i<20000;i++){};
				if (i2c_read_complete(buf_b,5)==0)	rd_wr_status=1;
				break;
			case 1:
				if ((i2c_write_complete(buf_b,5))==0) rd_wr_status=2;
				break;
			case 2:
				//if ((serial_write_complete(buf_b,5))==0)
				//{ 
					rd_wr_status=0;
					for (i=0;i<5;i++)
					{
					buf_b[i]=0;
					}
				//}
				break;
			}

		}
		
		/*
			if (I2CHW_1_bReadI2CStatus() & I2CHW_RD_COMPLETE)
		{
			PRT0DR &= ~0x80;
			
			I2CHW_1_ClrRdStatus();				// Clear the Read Complete Flag
			I2CHW_1_InitRamRead(buf,5);	// Initialize Read Buffer for Master to read the response
		}
		*/
	/*		I2CHW_1_fReadBytes(1, buf_b, 8, 0);		// Read 8 bytes from Slave and store in WriteBuffer
		while (!(I2CHW_1_bReadI2CStatus() & I2CHW_RD_COMPLETE)); 	// Wait for the operation to complete
		I2CHW_1_ClrRdStatus();							// Clear the Read Status
		serial_write_complete(buf_b,8);
		*/
//		i2c_write(buf,8,1);
//		for(i=0;i<500;i++){};


	//write(ReadBuffer,8);
		//serial_write_complete(ReadBuffer,8);
		//serial_write_complete(buf,8);
}

