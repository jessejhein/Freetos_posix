/*	Copyright (C) 2004 cheng chung yan <yan@amonics.com> for 8-bit system linlike8
 *	lib C in linlike8 8 bit system
 *
 *	updownptr.h
 *
 */

extern unsigned char up254buf(unsigned char adj_val, unsigned char cur_pos, unsigned char circular_flag, unsigned char max, unsigned char min);
extern unsigned char down254buf(unsigned char adj_val, unsigned char cur_pos, unsigned char circular_flag, unsigned char max, unsigned char min);

