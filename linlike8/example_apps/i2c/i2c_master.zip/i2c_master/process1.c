/*
 *	linlike8/test_apps/process1.c
 *
 *	linlike8 init task, it does to create others task
 *	but this task also can be one of task which will always running
 *
 *	16-04-2004	yan	just for test, real application should be have some job to do
 *
 */

#include "app.h"

#ifdef CYPRESS_PSOC
	#include <m8c.h>        // part specific constants and macros
	#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
	#include "sched.h"
	#include "timer.h"
#if (SERIAL_MOD>0)
	#include "serial.h"								// read()
#endif
#if (I2C_MOD>0)
	#include "i2c.h"								// read()
#endif
#endif

#ifdef I386_LINUX
	#include <sched.h>
	#include <stdio.h>
	#include <unistd.h>
#endif

#ifdef CYPRESS_PSOC
extern unsigned char a_glo;
#endif
#ifdef I386_LINUX
extern unsigned char* shmaddr;
#define	a_glo *shmaddr
#endif


void process1(void)
{
	//while (1) sched_yield();
	unsigned char i = 0;
	unsigned char buf[3];
	//unsigned char buf_b[5];
	//unsigned char j = 0;


}
